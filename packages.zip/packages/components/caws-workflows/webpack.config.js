module.exports = require('../../build/webpack-config');
