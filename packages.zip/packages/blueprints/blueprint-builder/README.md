
# Blueprint for Blueprint

This is a special blueprint that allows you to create blueprints from other blueprints.
