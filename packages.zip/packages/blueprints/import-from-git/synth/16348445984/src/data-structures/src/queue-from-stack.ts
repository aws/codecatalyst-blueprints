// FIFO queue with two stacks, first in, first out
export class Queue {
    
    constructor() {}

    peek(): Node | null {
        return null;
    }
    
    pop(): void {}

    push(node: Node): void {}

    getLength(): number {
       return 0;
    }

    arrayify(): any [] {
        return [];
    }
}
